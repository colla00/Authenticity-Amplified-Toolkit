import React from 'react';

function App() {
    return (
        <div>
            <h1>Authenticity Amplified: The Storyteller's Toolkit</h1>
            <p>Welcome to the storyteller's toolkit, a place for authentic and creative expression.</p>
        </div>
    );
}

export default App;